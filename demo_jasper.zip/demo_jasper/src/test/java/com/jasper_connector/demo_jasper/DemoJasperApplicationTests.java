
  package com.jasper_connector.demo_jasper;
  
  import org.junit.jupiter.api.Test; import
  org.springframework.boot.test.context.SpringBootTest;
  
  @SpringBootTest class DemoJasperApplicationTests {
  
  @Test void contextLoads() { }
  
  }
 