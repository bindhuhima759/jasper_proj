package connect_jasper.service;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.jasper_connector.demo_jasper.model.User;
import com.jasper_connector.demo_jasper.repository.UserRepository;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DataSource dataSource;

    @Autowired
    private ResourceLoader resourceLoader;

    public List<User> getAllUsers() {
        return userRepository.findAll(); // Fetch all users
    }

    public byte[] generateUserReport() throws Exception {
        // Load Jasper report from .jrxml file
        JasperReport jasperReport = JasperCompileManager.compileReport(resourceLoader.getResource("classpath:reports/user_report.jrxml").getInputStream());

        // Parameters for the report
        Map<String, Object> parameters = new HashMap<>();

        // Create a connection to the database
        try (Connection connection = dataSource.getConnection()) {
            // Fill the report with data
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);

            // Export the report to PDF
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            JasperExportManager.exportReportToPdfStream(jasperPrint, baos);
            
            return baos.toByteArray(); // Return the PDF as byte array
        } catch (SQLException e) {
            throw new RuntimeException("Error getting database connection", e);
        }
    }
}
