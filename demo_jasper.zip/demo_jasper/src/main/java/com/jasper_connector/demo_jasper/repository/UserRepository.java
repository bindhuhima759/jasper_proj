package com.jasper_connector.demo_jasper.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jasper_connector.demo_jasper.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
    // Custom query methods (if needed)
}
